from ft_package.count_in_list import count_in_list

def main():

    print(count_in_list(["a", "b", "a"], "a"))

if __name__ == "__main__":
    main()